package bank;

import java.util.ArrayList;

public class BankAccount {
	String state;
	int accountNumber;
	private double balance;
	private ArrayList<Double> TranscationList = null;// important

	public BankAccount() {
	}

	public BankAccount(int anAccountNumber) {
	}

	public BankAccount(int anAccountNumber, double initialBalance) {
	}

	boolean isOpen() {
		return false;
	}

	boolean isSuspended() {
		return false;
	}

	void reOpen() {

	}

	void deposit(double amount) {

	}

	void withdraw(double amount) {
	}

	void addTransaction(double amount) {

	}

	String getTransactions() {
		return "";
	}

	int retrieveNumberOfTransactions() {
		return -1;

	}
}