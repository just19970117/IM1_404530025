package bank;

public class Bank {

	public void addAccount(int accountNumber, double initialBalance) {

	}

	public void deposit(int accountNumber, double initialBalance) {

	}

	public void withdraw(int accountNumber, double initialBalance) {

	}

	public void getBalance(int accountNumber) {

	}

	public void suspendAccount(int accountNumber) {

	}

	public void reOpenAccount(int accountNumber) {

	}

	void closeAccount(int accountNumber) {
	}

	void getAccountStatus(int accountNumber) {

	}

	void summarizeAccountTransactions(int accountNumber) {

	}

	void summarizeAllAccounts() {

	}
}
