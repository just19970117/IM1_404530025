package bank;

import java.util.ArrayList;

public class bankAccount {
	String state;
	int accountNumber;
	private double balance;
	private ArrayList<Double> TranscationList = null;// important

	public bankAccount() {
	}

	public bankAccount(int anAccountNumber) {
	}

	public bankAccount(int anAccountNumber, double initialBalance) {
	}

	boolean isOpen() {
		return false;
	}

	boolean isSuspended() {
		return false;
	}

	void reOpen() {

	}

	void deposit(double amount) {

	}

	void withdraw(double amount) {
	}

	void addTransaction(double amount) {

	}

	String getTransactions() {
		return "";
	}

	int retrieveNumberOfTransactions() {
		return -1;

	}
}