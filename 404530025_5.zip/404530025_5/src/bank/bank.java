package bank;

public class bank {

	

	public void deposit(int accountNumber, double initialBalance) {

	}

	public void withdraw(int accountNumber, double initialBalance) {

	}

	public void getBalance(int accountNumber) {

	}

	public void suspendAccount(int accountNumber) {

	}

	public void reOpenAccount(int accountNumber) {

	}

	void closeAccount(int accountNumber) {
	}

	void getAccountStatus(int accountNumber) {

	}

	void summarizeAccountTransactions(int accountNumber) {

	}

	void summarizeAllAccounts() {

	}
}