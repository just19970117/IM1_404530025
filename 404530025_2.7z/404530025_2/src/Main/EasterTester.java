package Main;

public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Easter.yourfunction(2001));
		System.out.println(Easter.yourfunction(2012));
	
	}

}
